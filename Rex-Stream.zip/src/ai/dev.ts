import { config } from 'dotenv';
config();

import '@/ai/flows/ai-sentiment-matcher.ts';