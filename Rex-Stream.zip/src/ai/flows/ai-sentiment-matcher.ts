
'use server';
/**
 * @fileOverview An AI agent that suggests movies based on the user's sentiment or desired movie type.
 *
 * - suggestMoviesBySentiment - A function that handles the movie suggestion process.
 * - SuggestMoviesBySentimentInput - The input type for the suggestMoviesBySentiment function.
 * - SuggestMoviesBySentimentOutput - The return type for the suggestMoviesBySentiment function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestMoviesBySentimentInputSchema = z.object({
  sentimentDescription: z.string().describe("A natural language description of the user's current mood or the kind of movie they are looking for."),
});
export type SuggestMoviesBySentimentInput = z.infer<typeof SuggestMoviesBySentimentInputSchema>;

const MovieSuggestionSchema = z.object({
  title: z.string().describe('The title of the suggested movie.'),
  reason: z.string().describe("A brief explanation of why this movie matches the user's sentiment."),
  genre: z.string().describe('The primary genre of the suggested movie.'),
});

const SuggestMoviesBySentimentOutputSchema = z.object({
  suggestions: z.array(MovieSuggestionSchema).describe('A list of movie suggestions that match the user\'s sentiment.'),
});
export type SuggestMoviesBySentimentOutput = z.infer<typeof SuggestMoviesBySentimentOutputSchema>;

const prompt = ai.definePrompt({
  name: 'suggestMoviesBySentimentPrompt',
  input: {schema: SuggestMoviesBySentimentInputSchema},
  output: {schema: SuggestMoviesBySentimentOutputSchema},
  prompt: `You are REX Stream, an AI-powered movie recommendation system. Your goal is to suggest movies that perfectly match a user's described sentiment or desired movie type.\n\nThe user will provide a description of their current mood or what kind of movie they are looking for. Based on this, suggest 3-5 movies that truly resonate with their feelings. For each movie, provide the title, a concise reason why it fits the sentiment, and its primary genre.\n\nMake sure the suggestions are diverse and well-explained, focusing on emotional resonance and cinematic quality.\n\nUser sentiment/preference: {{{sentimentDescription}}}`,
});

const suggestMoviesBySentimentFlow = ai.defineFlow(
  {
    name: 'suggestMoviesBySentimentFlow',
    inputSchema: SuggestMoviesBySentimentInputSchema,
    outputSchema: SuggestMoviesBySentimentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

export async function suggestMoviesBySentiment(input: SuggestMoviesBySentimentInput): Promise<SuggestMoviesBySentimentOutput> {
  return suggestMoviesBySentimentFlow(input);
}
