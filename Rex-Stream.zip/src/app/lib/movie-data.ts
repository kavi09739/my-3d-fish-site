export interface Movie {
  id: string;
  title: string;
  description: string;
  year: number;
  rating: number;
  genre: string[];
  language: string;
  poster: string;
  backdrop: string;
  type: 'movie' | 'tv';
}

const TMDB_API_KEY = "cc4bacd13e262ba271ef2340a54da8cb";
const BASE_URL = "https://api.themoviedb.org/3";

export const GENRE_MAP: Record<number, string> = {
  28: "Action", 12: "Adventure", 16: "Animation", 35: "Comedy", 80: "Crime", 99: "Documentary", 18: "Drama", 10751: "Family", 14: "Fantasy", 36: "History", 27: "Horror", 10402: "Music", 9648: "Mystery", 10749: "Romance", 878: "Sci-Fi", 10770: "TV Movie", 53: "Thriller", 10752: "War", 37: "Western"
};

async function fetchTMDB(endpoint: string, params: Record<string, string> = {}) {
  const url = new URL(`${BASE_URL}${endpoint}`);
  url.searchParams.append('api_key', TMDB_API_KEY);
  url.searchParams.append('language', 'en-US');
  Object.entries(params).forEach(([key, value]) => url.searchParams.append(key, value));

  try {
    const response = await fetch(url.toString(), { 
      next: { revalidate: 3600 }
    });
    if (!response.ok) return { results: [] };
    return response.json();
  } catch (error) {
    console.error("TMDB Error:", error);
    return { results: [] };
  }
}

export function mapTMDBMovie(m: any, type: 'movie' | 'tv' = 'movie'): Movie {
  return {
    id: m.id.toString(),
    title: m.title || m.name,
    description: m.overview || "No description available.",
    year: (m.release_date || m.first_air_date) ? new Date(m.release_date || m.first_air_date).getFullYear() : 0,
    rating: m.vote_average ? parseFloat(m.vote_average.toFixed(1)) : 0,
    genre: m.genre_ids ? m.genre_ids.map((id: number) => GENRE_MAP[id] || "Other") : [],
    language: m.original_language,
    poster: m.poster_path ? `https://image.tmdb.org/t/p/w500${m.poster_path}` : "https://picsum.photos/seed/movie/500/750",
    backdrop: m.backdrop_path ? `https://image.tmdb.org/t/p/original${m.backdrop_path}` : "https://picsum.photos/seed/backdrop/1920/1080",
    type
  };
}

export async function getTrending(type: 'movie' | 'tv' = 'movie', page = 1) {
  // Use popular or now_playing for home page movies
  const endpoint = type === 'movie' ? '/movie/now_playing' : '/tv/popular';
  const data = await fetchTMDB(endpoint, { page: page.toString() });
  return data.results ? data.results.map((m: any) => mapTMDBMovie(m, type)) : [];
}

export async function searchContent(query: string, page = 1) {
  const data = await fetchTMDB('/search/multi', { query, page: page.toString(), include_adult: 'false' });
  return data.results 
    ? data.results
        .filter((i: any) => i.media_type === 'movie' || i.media_type === 'tv')
        .map((i: any) => mapTMDBMovie(i, i.media_type))
    : [];
}

export async function getTVDetails(id: string) {
  return fetchTMDB(`/tv/${id}`);
}