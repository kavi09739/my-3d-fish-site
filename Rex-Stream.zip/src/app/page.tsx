"use client";

import { useState, useEffect } from "react";
import { Movie, getTrending, searchContent } from "@/app/lib/movie-data";
import { Navbar } from "@/components/layout/Navbar";
import { MovieCard } from "@/components/movie/MovieCard";
import { MinimalPlayer } from "@/components/movie/MinimalPlayer";
import { DesktopModeAlert } from "@/components/movie/DesktopModeAlert";
import { FilterBar } from "@/components/movie/FilterBar";
import { Loader2, ChevronDown, Play, Tv } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [content, setContent] = useState<Movie[]>([]);
  const [contentType, setContentType] = useState<'movie' | 'tv'>('movie');
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [playingMovie, setPlayingMovie] = useState<Movie | null>(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const data = searchTerm 
        ? await searchContent(searchTerm, 1)
        : await getTrending(contentType, 1);
      setContent(data);
      setLoading(false);
      setPage(1);
    }
    load();
  }, [contentType, searchTerm]);

  const loadMore = async () => {
    const nextPage = page + 1;
    const more = searchTerm 
      ? await searchContent(searchTerm, nextPage)
      : await getTrending(contentType, nextPage);
    setContent(prev => [...prev, ...more]);
    setPage(nextPage);
  };

  return (
    <main className="min-h-screen pb-20 selection:bg-primary/30">
      <DesktopModeAlert />
      <Navbar onSearch={setSearchTerm} />
      
      <div className="pt-32 max-w-[1800px] mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div className="space-y-2">
            <h2 className="text-4xl md:text-5xl font-black text-white uppercase tracking-tighter italic text-glow">
              {searchTerm ? `Search Results` : `Discovery`}
            </h2>
            <p className="text-muted-foreground text-sm font-medium tracking-widest uppercase">
              Explore the finest cinema curated by REX AI
            </p>
          </div>

          <div className="flex bg-white/5 p-1.5 rounded-2xl border border-white/5 backdrop-blur-xl">
            <Button 
              variant="ghost" 
              size="sm"
              className={`rounded-xl px-6 gap-2 text-xs font-bold uppercase tracking-widest transition-all duration-500 ${contentType === 'movie' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-white/40'}`}
              onClick={() => setContentType('movie')}
            >
              <Play className="w-3.5 h-3.5" /> Movies
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              className={`rounded-xl px-6 gap-2 text-xs font-bold uppercase tracking-widest transition-all duration-500 ${contentType === 'tv' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-white/40'}`}
              onClick={() => setContentType('tv')}
            >
              <Tv className="w-3.5 h-3.5" /> TV Shows
            </Button>
          </div>
        </div>

        <FilterBar />

        {loading ? (
          <div className="flex h-80 items-center justify-center">
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
          </div>
        ) : (
          <>
            <div className="movie-grid">
              {content.map((movie) => (
                <MovieCard key={movie.id} movie={movie} onClick={setPlayingMovie} />
              ))}
            </div>
            {content.length > 0 && (
              <div className="flex justify-center mt-20">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="rounded-2xl glass-card border-white/10 hover:border-primary/50 px-12 h-14 font-black uppercase tracking-widest text-xs" 
                  onClick={loadMore}
                >
                  <ChevronDown className="w-5 h-5 mr-3 text-primary" /> Load More Masterpieces
                </Button>
              </div>
            )}
          </>
        )}
      </div>

      {playingMovie && <MinimalPlayer movie={playingMovie} onClose={() => setPlayingMovie(null)} />}
    </main>
  );
}