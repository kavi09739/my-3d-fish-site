
"use client";

import Link from "next/link";
import { Search, Monitor, Share2 } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export function Navbar({ onSearch }: { onSearch: (t: string) => void }) {
  const [scrolled, setScrolled] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleShare = () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      navigator.share({
        title: 'REX STREAM',
        text: 'Check out this awesome movie streaming site!',
        url: window.location.href,
      }).catch(() => {
        // Fallback to clipboard
        copyToClipboard();
      });
    } else {
      copyToClipboard();
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({
      title: "Link Copied!",
      description: "REX STREAM link copied to clipboard. Share it with your friends!",
    });
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-500 ${scrolled ? 'glass h-16' : 'bg-transparent h-24'}`}>
      <div className="max-w-[1800px] mx-auto h-full flex items-center justify-between px-6 md:px-12">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-10 h-10 purple-gradient rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
            <Monitor className="w-6 h-6 text-white" />
          </div>
          <span className="text-2xl md:text-3xl font-black text-white tracking-tighter uppercase italic text-glow">
            REX<span className="text-primary not-italic">STREAM</span>
          </span>
        </Link>

        <div className="relative max-w-xs md:max-w-xl w-full mx-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input 
            placeholder="Search Masterpieces..." 
            className="w-full pl-12 bg-white/5 border border-white/5 rounded-2xl focus:bg-white/10 focus:border-primary/50 outline-none transition-all h-11 md:h-12 text-sm backdrop-blur-md text-white placeholder:text-white/30"
            onChange={(e) => onSearch(e.target.value)}
          />
        </div>

        <div className="hidden lg:flex items-center gap-6">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleShare} 
            className="rounded-xl hover:bg-white/10 text-white transition-all hover:scale-110 active:scale-90"
            title="Share with Friends"
          >
            <Share2 className="w-5 h-5" />
          </Button>
          <Link href="/" className="text-xs font-bold uppercase tracking-widest text-white/70 hover:text-primary transition-colors">Home</Link>
          <Link href="#" className="text-xs font-bold uppercase tracking-widest text-white/70 hover:text-primary transition-colors">Premium</Link>
        </div>
      </div>
    </nav>
  );
}
