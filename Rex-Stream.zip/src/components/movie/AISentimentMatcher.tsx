
"use client";

import { useState } from "react";
import { suggestMoviesBySentiment } from "@/ai/flows/ai-sentiment-matcher";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles, Loader2, PlayCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export function AISentimentMatcher() {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const { toast } = useToast();

  const handleSuggest = async () => {
    if (!input.trim()) return;
    setLoading(true);
    try {
      const result = await suggestMoviesBySentiment({ sentimentDescription: input });
      setSuggestions(result.suggestions);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get AI recommendations. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-10 md:py-20 px-4 md:px-8 max-w-7xl mx-auto w-full">
      <div className="glass rounded-2xl p-6 md:p-12 relative overflow-hidden">
        <div className="max-w-2xl relative z-10">
          <h2 className="text-xl md:text-3xl font-headline font-bold mb-3 flex items-center gap-2">
            <Sparkles className="text-accent w-5 h-5 md:w-7 md:h-7" /> AI Mood Matcher
          </h2>
          <p className="text-xs md:text-base text-muted-foreground mb-6">
            Tell us how you're feeling and REX AI will curate the perfect watchlist.
          </p>

          <div className="space-y-4">
            <Textarea
              placeholder="e.g., 'I want something dark and philosophical...'"
              className="bg-background/50 border-muted focus:border-primary text-xs md:text-base p-4 min-h-[80px] rounded-xl"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <Button 
              size="lg" 
              className="w-full md:w-auto h-10 md:h-12 px-6 gap-2 rounded-xl text-xs md:text-base font-semibold" 
              onClick={handleSuggest}
              disabled={loading || !input.trim()}
            >
              {loading ? <Loader2 className="animate-spin w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
              Generate Suggestions
            </Button>
          </div>
        </div>

        {suggestions.length > 0 && (
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 animate-fade-in relative z-10">
            {suggestions.map((s, i) => (
              <Card key={i} className="bg-background/40 border-muted/50 hover:border-primary/50 transition-colors">
                <CardContent className="p-4 space-y-3">
                  <div className="flex justify-between items-start gap-2">
                    <h3 className="text-sm md:text-base font-headline font-semibold text-primary line-clamp-1">{s.title}</h3>
                    <Badge variant="secondary" className="text-[8px] flex-shrink-0">{s.genre}</Badge>
                  </div>
                  <p className="text-[10px] text-muted-foreground leading-relaxed italic line-clamp-2">
                    "{s.reason}"
                  </p>
                  <Button variant="ghost" className="w-full h-8 gap-2 text-accent hover:text-accent hover:bg-accent/10 text-[10px]">
                    <PlayCircle className="w-3 h-3" /> Watch Preview
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
