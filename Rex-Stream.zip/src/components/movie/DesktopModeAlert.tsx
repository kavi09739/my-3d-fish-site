"use client";

import { useState, useEffect } from "react";
import { Laptop, X, AlertCircle, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";

export function DesktopModeAlert() {
  const [isMobile, setIsMobile] = useState(false);
  const [showCloseButton, setShowCloseButton] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const checkSize = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    checkSize();
    window.addEventListener("resize", checkSize);

    // Show close button after 5 seconds
    const timer = setTimeout(() => {
      setShowCloseButton(true);
    }, 5000);

    return () => {
      window.removeEventListener("resize", checkSize);
      clearTimeout(timer);
    };
  }, []);

  if (!isMobile || dismissed) return null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-black/60 backdrop-blur-md animate-in fade-in duration-500">
      <div className="glass-card max-w-md w-full p-8 rounded-[2rem] border border-white/10 shadow-2xl relative overflow-hidden flex flex-col items-center text-center">
        
        {/* Background Glow */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-primary/20 rounded-full blur-[80px]" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-primary/20 rounded-full blur-[80px]" />

        <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 border border-primary/20 animate-pulse">
          <Monitor className="w-10 h-10 text-primary" />
        </div>

        <h1 className="text-3xl font-black uppercase tracking-tighter text-white mb-2 italic text-glow font-headline">
          REX<span className="text-primary not-italic">STREAM</span>
        </h1>
        
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/5 rounded-full border border-white/10 mb-6">
          <AlertCircle className="w-3 h-3 text-primary" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Optimization Required</span>
        </div>

        <h2 className="text-xl font-bold text-white mb-4 font-headline">Switch to Desktop Mode</h2>
        
        <p className="text-white/60 text-sm leading-relaxed mb-8 font-medium">
          For the ultimate cinematic experience with ultra-high bitrate and premium visuals, we recommend using a desktop computer or enabling <b>Desktop Mode</b>.
        </p>

        <div className="w-full space-y-4">
          {!showCloseButton ? (
            <div className="flex flex-col items-center gap-2">
              <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-primary animate-[progress_5s_linear_forwards]" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">Wait 5 seconds...</span>
            </div>
          ) : (
            <Button 
              className="w-full h-14 rounded-2xl bg-white text-black hover:bg-white/90 font-black uppercase tracking-widest text-xs gap-3 shadow-xl transition-all duration-300 hover:scale-[1.02] active:scale-95"
              onClick={() => setDismissed(true)}
            >
              <X className="w-4 h-4" /> Close and Continue
            </Button>
          )}
        </div>

        <div className="mt-8 pt-6 border-t border-white/5 w-full flex justify-between items-center">
          <span className="text-[9px] font-mono text-white/20 uppercase tracking-widest">Build v2.4.0</span>
          <div className="flex gap-1">
            <div className="w-1 h-1 bg-primary rounded-full" />
            <div className="w-1 h-1 bg-primary/40 rounded-full" />
            <div className="w-1 h-1 bg-primary/10 rounded-full" />
          </div>
        </div>
      </div>
      
      <style jsx global>{`
        @keyframes progress {
          from { width: 0%; }
          to { width: 100%; }
        }
      `}</style>
    </div>
  );
}
