"use client";

import { useState } from "react";
import { ChevronDown, Filter, Calendar, Globe, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function FilterBar() {
  const languages = ["English", "Spanish", "French", "Japanese", "Korean", "Hindi"];
  const years = Array.from({ length: 15 }, (_, i) => 2024 - i);
  const categories = ["Trending", "Newest", "Top Rated", "Best IMDb"];

  return (
    <div className="flex flex-wrap items-center gap-3 mb-8">
      <div className="p-2 bg-primary/10 rounded-xl border border-primary/20 flex items-center gap-2 px-4 mr-2">
        <Filter className="w-4 h-4 text-primary" />
        <span className="text-xs font-bold uppercase tracking-widest text-primary">Filters</span>
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="glass-card border-white/5 rounded-xl gap-2 h-11 text-xs font-bold uppercase tracking-widest">
            <Calendar className="w-3.5 h-3.5" /> Year <ChevronDown className="w-3.5 h-3.5 opacity-50" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="glass border-white/10 min-w-[120px]">
          {years.map(y => <DropdownMenuItem key={y} className="text-xs font-bold focus:bg-primary/20 focus:text-primary">{y}</DropdownMenuItem>)}
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="glass-card border-white/5 rounded-xl gap-2 h-11 text-xs font-bold uppercase tracking-widest">
            <Globe className="w-3.5 h-3.5" /> Language <ChevronDown className="w-3.5 h-3.5 opacity-50" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="glass border-white/10 min-w-[140px]">
          {languages.map(l => <DropdownMenuItem key={l} className="text-xs font-bold focus:bg-primary/20 focus:text-primary">{l}</DropdownMenuItem>)}
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="glass-card border-white/5 rounded-xl gap-2 h-11 text-xs font-bold uppercase tracking-widest">
            <Star className="w-3.5 h-3.5" /> Category <ChevronDown className="w-3.5 h-3.5 opacity-50" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="glass border-white/10 min-w-[140px]">
          {categories.map(c => <DropdownMenuItem key={c} className="text-xs font-bold focus:bg-primary/20 focus:text-primary">{c}</DropdownMenuItem>)}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}