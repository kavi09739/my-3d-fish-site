
"use client";

import { GENRES } from "@/app/lib/movie-data";
import { Button } from "@/components/ui/button";

interface GenreExplorerProps {
  onGenreSelect: (genre: string) => void;
  activeGenre: string | null;
}

export function GenreExplorer({ onGenreSelect, activeGenre }: GenreExplorerProps) {
  return (
    <div className="flex flex-col gap-4 md:gap-6 w-full max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-12">
      <div className="flex items-end justify-between">
        <h2 className="text-xl md:text-3xl font-headline font-bold">Explore Genres</h2>
        <Button variant="link" className="text-accent text-xs md:text-sm">View All</Button>
      </div>
      <div className="flex items-center gap-2 md:gap-3 overflow-x-auto pb-2 md:pb-4 no-scrollbar">
        {GENRES.map((genre) => (
          <Button
            key={genre}
            variant={activeGenre === genre ? "default" : "secondary"}
            className={`rounded-full px-5 md:px-8 py-4 md:py-6 text-xs md:text-base font-medium transition-all duration-300 flex-shrink-0 ${activeGenre === genre ? 'shadow-lg shadow-primary/20 scale-105' : 'hover:bg-primary/10'}`}
            onClick={() => onGenreSelect(genre)}
          >
            {genre}
          </Button>
        ))}
      </div>
    </div>
  );
}
