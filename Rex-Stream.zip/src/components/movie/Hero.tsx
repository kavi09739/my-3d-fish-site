
"use client";

import Image from "next/image";
import { Movie } from "@/app/lib/movie-data";
import { Button } from "@/components/ui/button";
import { Play, Info } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface HeroProps {
  movie: Movie;
  onPlay: (movie: Movie) => void;
  onInfo: (movie: Movie) => void;
}

export function Hero({ movie, onPlay, onInfo }: HeroProps) {
  return (
    <div className="relative w-full h-[45vh] md:h-[80vh] min-h-[300px] flex items-end overflow-hidden">
      <div className="absolute inset-0 z-0">
        <Image
          src={movie.backdrop}
          alt={movie.title}
          fill
          className="object-cover opacity-60 md:opacity-70"
          priority
          data-ai-hint="cinematic background"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 pb-8 md:pb-20 w-full animate-slide-up">
        <div className="max-w-2xl space-y-2 md:space-y-4">
          <Badge variant="outline" className="text-accent border-accent bg-accent/10 px-2 py-0.5 font-headline font-semibold text-[8px] md:text-[10px]">
            TRENDING NOW
          </Badge>
          <h1 className="text-xl md:text-6xl font-headline font-bold text-glow tracking-tight leading-tight line-clamp-2">
            {movie.title}
          </h1>
          <p className="text-[10px] md:text-base text-muted-foreground line-clamp-2 leading-relaxed max-w-xl hidden sm:block">
            {movie.description}
          </p>
          <div className="flex items-center gap-2 pt-1 md:pt-2">
            <Button size="sm" className="h-8 md:h-12 px-4 md:px-8 gap-1.5 md:gap-3 text-[10px] md:text-base font-semibold rounded-full" onClick={() => onPlay(movie)}>
              <Play className="w-3 h-3 md:w-4 md:h-4 fill-current" /> Play
            </Button>
            <Button size="sm" variant="secondary" className="h-8 md:h-12 px-4 md:px-8 gap-1.5 md:gap-3 text-[10px] md:text-base font-semibold rounded-full" onClick={() => onInfo(movie)}>
              <Info className="w-3 h-3 md:w-4 md:h-4" /> Details
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
