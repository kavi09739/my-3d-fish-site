
"use client";

import { X, Play, Download, Layers, LayoutGrid, Monitor, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Movie, getTVDetails } from "@/app/lib/movie-data";
import { useEffect, useState } from "react";
import Image from "next/image";
import { ScrollArea } from "@/components/ui/scroll-area";

export function MinimalPlayer({ movie, onClose }: { movie: Movie, onClose: () => void }) {
  const [activeServer, setActiveServer] = useState(1);
  const [season, setSeason] = useState(1);
  const [episode, setEpisode] = useState(1);
  const [tvDetails, setTvDetails] = useState<any>(null);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    if (movie.type === 'tv') {
      getTVDetails(movie.id).then(data => {
        if (data && data.seasons) {
          setTvDetails(data);
          const s1 = data.seasons.find((s: any) => s.season_number > 0) || data.seasons[0];
          if (s1) setSeason(s1.season_number);
        }
      });
    }
    return () => { document.body.style.overflow = "auto"; };
  }, [movie]);

  const getUrl = () => {
    let url = "";
    if (movie.type === 'tv') {
      if (activeServer === 1) {
        url = `https://vidsrc.to/embed/tv/${movie.id}/${season}/${episode}`;
      } else {
        url = `https://multiembed.mov/?video_id=${movie.id}&tmdb=1&s=${season}&e=${episode}`;
      }
    } else {
      if (activeServer === 1) {
        url = `https://vidsrc.to/embed/movie/${movie.id}`;
      } else {
        url = `https://multiembed.mov/?video_id=${movie.id}&tmdb=1`;
      }
    }
    console.log(`[REX PLAYER] Loading URL (Server ${activeServer}):`, url);
    return url;
  };

  const handleDownload = () => {
    const q = `${movie.title} ${movie.year} ${movie.type === 'tv' ? `S${season}E${episode}` : ''} download free`;
    window.open(`https://www.google.com/search?q=${encodeURIComponent(q)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center p-2 md:p-6 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="bg-card w-full max-w-6xl max-h-[95vh] overflow-hidden rounded-2xl border border-white/10 flex flex-col relative shadow-2xl">
        
        <Button variant="ghost" size="icon" className="absolute top-4 right-4 z-[210] rounded-full bg-black/50 hover:bg-primary transition-colors" onClick={onClose}>
          <X className="w-6 h-6 text-white" />
        </Button>

        <div className="aspect-video w-full bg-black relative">
          <iframe 
            src={getUrl()} 
            className="w-full h-full border-none" 
            allowFullScreen 
            allow="autoplay; encrypted-media" 
            key={`${activeServer}-${season}-${episode}`}
            title="Movie Player"
          />
        </div>

        <ScrollArea className="flex-1 p-4 md:p-8">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="w-32 md:w-48 shrink-0 shadow-2xl rounded-xl overflow-hidden border border-white/10 hidden sm:block">
              <Image src={movie.poster} alt={movie.title} width={200} height={300} className="object-cover" />
            </div>

            <div className="flex-1 space-y-6">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <span className="bg-primary text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest italic shadow-lg shadow-primary/20">REX {movie.type}</span>
                  <span className="text-white/60 font-black text-sm">{movie.year}</span>
                </div>
                <h1 className="text-2xl md:text-4xl font-black uppercase tracking-tighter text-white italic text-glow">{movie.title}</h1>
                <p className="text-white/40 text-xs md:text-sm leading-relaxed max-w-3xl line-clamp-3 font-medium">{movie.description}</p>
              </div>

              {movie.type === 'tv' && tvDetails && (
                <div className="space-y-6 pt-4 border-t border-white/5">
                  <div className="space-y-3">
                    <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] flex items-center gap-2">
                      <Layers className="w-4 h-4 text-primary" /> Select Season
                    </p>
                    <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                      {tvDetails.seasons.filter((s: any) => s.season_number > 0).map((s: any) => (
                        <Button 
                          key={s.season_number} 
                          variant={season === s.season_number ? "default" : "outline"} 
                          className={`rounded-xl h-10 px-6 shrink-0 font-black text-xs uppercase tracking-widest transition-all duration-300 ${season === s.season_number ? 'bg-primary text-white shadow-xl shadow-primary/30 scale-105' : 'border-white/5 text-white/40 hover:bg-white/5'}`} 
                          onClick={() => { setSeason(s.season_number); setEpisode(1); }}
                        >
                          S{s.season_number}
                        </Button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] flex items-center gap-2">
                      <LayoutGrid className="w-4 h-4 text-primary" /> Select Episode
                    </p>
                    <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12 gap-2">
                      {Array.from({ length: tvDetails.seasons.find((s: any) => s.season_number === season)?.episode_count || 1 }, (_, i) => i + 1).map(ep => (
                        <Button 
                          key={ep} 
                          variant={episode === ep ? "default" : "outline"} 
                          className={`h-11 rounded-xl p-0 font-black text-sm transition-all duration-300 ${episode === ep ? 'bg-primary text-white shadow-xl shadow-primary/30 scale-110' : 'border-white/5 text-white/40 hover:bg-white/5'}`} 
                          onClick={() => setEpisode(ep)}
                        >
                          {ep}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-6 space-y-6 border-t border-white/5">
                <div className="space-y-3">
                  <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] flex items-center gap-2">
                    <Monitor className="w-4 h-4 text-primary" /> Select Quality Server
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    <Button 
                      variant={activeServer === 1 ? "default" : "outline"} 
                      className={`h-16 rounded-2xl font-black uppercase tracking-[0.15em] text-[10px] md:text-xs transition-all duration-500 ${activeServer === 1 ? 'bg-primary text-white shadow-2xl shadow-primary/40' : 'border-white/5 text-white/40 hover:bg-white/5'}`} 
                      onClick={() => setActiveServer(1)}
                    >
                      Server 1 (VidSrc)
                    </Button>
                    <Button 
                      variant={activeServer === 2 ? "default" : "outline"} 
                      className={`h-16 rounded-2xl font-black uppercase tracking-[0.15em] text-[10px] md:text-xs transition-all duration-500 ${activeServer === 2 ? 'bg-primary text-white shadow-2xl shadow-primary/40' : 'border-white/5 text-white/40 hover:bg-white/5'}`} 
                      onClick={() => setActiveServer(2)}
                    >
                      Server 2 (MultiEmbed)
                    </Button>
                  </div>
                </div>

                <Button className="w-full h-16 bg-white text-black hover:bg-white/90 text-sm font-black uppercase tracking-[0.2em] gap-3 shadow-2xl rounded-2xl transition-all duration-300 hover:scale-[1.01] active:scale-95" onClick={handleDownload}>
                  <Download className="w-5 h-5" /> Download Content
                </Button>

                <div className="flex items-center justify-center gap-3 opacity-30">
                  <Shield className="w-4 h-4 text-primary" />
                  <span className="text-[9px] font-black uppercase tracking-[0.3em] text-white">Secure Premium High Bitrate Stream</span>
                </div>
              </div>
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
