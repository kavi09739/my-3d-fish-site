"use client";

import Image from "next/image";
import { Movie } from "@/app/lib/movie-data";
import { Star, Play } from "lucide-react";

export function MovieCard({ movie, onClick }: { movie: Movie, onClick: (m: Movie) => void }) {
  return (
    <div className="glass-card group rounded-2xl overflow-hidden cursor-pointer relative" onClick={() => onClick(movie)}>
      <div className="aspect-[2/3] relative">
        <Image 
          src={movie.poster} 
          alt={movie.title} 
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center">
           <div className="w-14 h-14 bg-primary rounded-full flex items-center justify-center scale-75 group-hover:scale-100 transition-transform duration-500 shadow-2xl shadow-primary/50">
             <Play className="w-6 h-6 text-white fill-current ml-1" />
           </div>
        </div>
      </div>
      
      <div className="p-4 space-y-2">
        <h3 className="text-white font-bold text-sm line-clamp-1 group-hover:text-primary transition-colors">{movie.title}</h3>
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{movie.year}</span>
          <div className="flex items-center gap-1.5 bg-black/40 px-2 py-0.5 rounded-lg border border-white/5">
            <Star className="w-3 h-3 text-primary fill-current" />
            <span className="text-[10px] font-black text-white">{movie.rating}</span>
          </div>
        </div>
      </div>

      <div className="absolute top-3 left-3 px-2 py-1 glass rounded-lg border border-white/10 text-[9px] font-black text-white uppercase tracking-widest z-10">
        PREMIUM
      </div>
    </div>
  );
}